export const MOCK_USERS = [
  { id: '1', email: 'owner@company.com',   name: 'Owner',   role: 'owner',   password_plaintext: 'password123' },
  { id: '2', email: 'manager@company.com', name: 'Manager', role: 'manager', password_plaintext: 'password123' },
  { id: '3', email: 'leader@company.com',  name: 'Leader',  role: 'leader',  password_plaintext: 'password123' },
  { id: '4', email: 'employee@company.com',name: 'Employee',role: 'employee',password_plaintext: 'password123' },
  { id: '5', email: 'admin@admin.com',     name: 'Admin',   role: 'admin',   password_plaintext: 'password123' },
];
